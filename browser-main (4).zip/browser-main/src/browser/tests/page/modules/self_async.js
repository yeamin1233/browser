const c = await import('./self_async.js');
