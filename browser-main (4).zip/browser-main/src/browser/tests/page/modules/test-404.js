import { something } from './nonexistent.js';
export { something };
