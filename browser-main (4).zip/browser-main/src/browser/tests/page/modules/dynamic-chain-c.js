export const finalValue = 'chain-end';
