import { baseValue } from './base.js';

export const importedValue = baseValue;
export const localValue = 'local';
