export const value = 'test'
this is a syntax error!
