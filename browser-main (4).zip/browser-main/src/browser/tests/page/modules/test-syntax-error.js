import { value } from './syntax-error.js';
export { value };
