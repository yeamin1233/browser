const val1 = 'value-1';
export { val1 as "val1" }
