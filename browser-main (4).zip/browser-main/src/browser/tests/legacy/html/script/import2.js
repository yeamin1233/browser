let greeting = 'world';
export {greeting as 'greeting'};
