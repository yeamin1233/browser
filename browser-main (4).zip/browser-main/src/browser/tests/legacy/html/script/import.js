let greeting = 'hello';
export {greeting as 'greeting'};
