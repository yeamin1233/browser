list += 'a';
testing.expectEqual('a', list);
